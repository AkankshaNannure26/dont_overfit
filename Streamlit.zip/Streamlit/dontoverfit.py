import numpy as np
import pandas as pd
import pickle 
import streamlit as st
from io import StringIO
import joblib
import sklearn
from sklearn.metrics import  roc_auc_score
preprocess=joblib.load('preprocessing.sav')
best_model=joblib.load('Baseline_fe_LRmodel.sav')


def feature_enng(df):
    temp = df

    # Mean and Std FE
    df['mean'] = np.mean(temp, axis=1)
    df['std'] = np.std(temp, axis=1)

    # Trigometric FE
    sin_temp = np.sin(temp)
    cos_temp = np.cos(temp)
    tan_temp = np.tan(temp)
    df['mean_sin'] = np.mean(sin_temp, axis=1)
    df['mean_cos'] = np.mean(cos_temp, axis=1)
    df['mean_tan'] = np.mean(tan_temp, axis=1)

    # Hyperbolic FE
    sinh_temp = np.sinh(temp)
    cosh_temp = np.cosh(temp)
    tanh_temp = np.tanh(temp)
    df['mean_sinh'] = np.mean(sin_temp, axis=1)
    df['mean_cosh'] = np.mean(cos_temp, axis=1)
    df['mean_tanh'] = np.mean(tan_temp, axis=1)

    # Exponents FE
    exp_temp = np.exp(temp)
    expm1_temp = np.expm1(temp)
    exp2_temp = np.exp2(temp)
    df['mean_exp'] = np.mean(exp_temp, axis=1)
    df['mean_expm1'] = np.mean(expm1_temp, axis=1)
    df['mean_exp2'] = np.mean(exp2_temp, axis=1)

    # Polynomial FE
    # X**2
    df['mean_x2'] = np.mean(np.power(temp,2), axis=1)
    # X**3
    df['mean_x3'] = np.mean(np.power(temp,3), axis=1)
    # X**4
    df['mean_x4'] = np.mean(np.power(temp,4), axis=1)

    return df
def main():
    st.title("CASE STUDY1") #simple title for the app
    html_temp="""
        <div>
        <h2>DONT OVERFIT </h2>
        </div>
        """
    st.markdown(html_temp,unsafe_allow_html=True) #a simple html 
    #st.write(sklearn.__version__)
    uploaded_file = st.file_uploader("Upload a csv file on which you want to predict the probability for the target variable")
    if uploaded_file is not None:
        bytes_data = uploaded_file.getvalue()
        stringio = StringIO(uploaded_file.getvalue().decode("utf-8"))
        string_data = stringio.read()
        dataframe = pd.read_csv(uploaded_file)
        
    result=""
    preprocess=joblib.load('preprocessing.sav')
    best_model=joblib.load('Baseline_fe_LRmodel.sav')

    if st.button("Predict"):
        preprocess=joblib.load('scaling_preprocessmodel.sav')
        best_model=joblib.load('Baseline_fe_LRmodel.sav')
        test=feature_enng(dataframe.drop(['id'],axis=1))
        X = preprocess.transform(test)
        pred=best_model.predict_proba(X)[:,1]
        st.success('We have got the result!')
        st.write(pred)
        
    
    
if __name__=='__main__':
    main()